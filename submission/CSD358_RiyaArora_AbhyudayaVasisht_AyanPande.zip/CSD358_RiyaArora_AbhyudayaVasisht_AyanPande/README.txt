CSD358 — Evidence-First Deep Research in Pi
Group: Riya Arora, Abhyudaya Vasisht, Ayan Pande
GitHub: https://github.com/CloudedQuartz/pi-research

project-report.pdf is the submission report. source/ contains the evaluated
Pi working copy, the additional retrieval implementation, and the judge code.
The judge scripts are archived as run; adjust their data-root path to the local
extraction directory and supply your own JUDGE_KEY to rerun scoring. No
credentials or dependency directories are bundled. results/ contains the two
concluded DeepResearch Bench runs and their official-rubric scores.

DeepResearch Bench inputs in dataset/deepresearch-bench are from
https://huggingface.co/datasets/muset-ai/DeepResearch-Bench-Dataset .
BrowseComp-Plus is documented separately in dataset/browsecomp-plus/SOURCES.txt;
its full web corpus and qrel files are not bundled in this archive.
